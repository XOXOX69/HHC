<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::get("/", [DashboardController::class, 'getDashboardData']);
Route::get("/chart-data", [DashboardController::class, 'getChartData']);
Route::get("/active-users", [DashboardController::class, 'getActiveUsers']);
