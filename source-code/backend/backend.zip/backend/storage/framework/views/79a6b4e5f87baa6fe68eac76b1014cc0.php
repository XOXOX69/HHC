

<?php /**PATH C:\Users\dex\Desktop\codecanyon-MlpTtcAY-pos-os-pos-invoice-inventory-accounting-staff-and-shop-management-software\source-code\backend\backend\resources\views\layouts\header.blade.php ENDPATH**/ ?>