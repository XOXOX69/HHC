<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>New account</title>
</head>
<body>
<h3>Hello, <?php echo e($mailData['name']); ?></h3>
<h3>Welcome to <?php echo e($mailData['companyName']); ?>. Here is your account credentials.</h3>
<h3>Email: <strong><?php echo e($mailData["email"]); ?></strong></h3>
<h3>Password: <strong><?php echo e($mailData['password']); ?></strong></h3>
<h3>Thank you,</h3>
<h3><?php echo e($mailData['companyName']); ?></h3>
<span style="color: gray;">P.S : We recommend you to change your password after login.</span><br>
<span style="color: gray;">Note : This is an automated email. Please do not reply to this email.</span>
</body>
</html>
<?php /**PATH C:\Users\dex\Desktop\codecanyon-MlpTtcAY-pos-os-pos-invoice-inventory-accounting-staff-and-shop-management-software\source-code\backend\backend\resources\views\newAccount.blade.php ENDPATH**/ ?>