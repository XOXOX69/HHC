
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }

        .email-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1, h2, p {
            color: #333333;
            margin: 0;
        }

        h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .button-64 {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #ffffff;
            background: linear-gradient(144deg, #AF40FF, #5B42F3 50%, #00DDEB);
            border-radius: 8px;
            padding: 12px 20px;
            font-size: 16px;
            transition: background 0.3s ease;
        }

        .button-64:hover {
            background: linear-gradient(144deg, #5B42F3, #AF40FF 50%, #00DDEB);
        }

        .ticket-details {
            background-color: #f5f5f5;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
        }

        .ticket-details h2 {
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ccc;
        }

        .ticket-details p {
            margin: 10px 0;
            line-height: 1.4;
        }

        .contact-info {
            margin-top: 20px;
            font-size: 14px;
            color: #777777;
        }
    </style>
</head>

<body>
    <div class="email-container">
        <h1>Your Order Status updated!</h1>
        <p>Hi <?php echo e($customerName); ?>,</p>
        <p>Your order <strong><?php echo e($invoiceId); ?></strong> has been <strong><?php echo e($OrderStatus); ?></strong></p>
        <div class="ticket-details">
            <h2>Delivery Details</h2>
            <p><strong>Name:</strong> <?php echo e($customerName); ?></p>
            <p><strong>Address:</strong> <?php echo e($deliveryAddress); ?></p>
            <p><strong>Phone:</strong> <?php echo e($customerPhone); ?></p>
            <p><strong>Email:</strong> <?php echo e($customerEmail); ?></p>
        </div>

        <div class="ticket-details">
            <h2>Order Details</h2>
            <p><strong>ID:</strong> <?php echo e($invoiceId); ?></p>
            <p><strong>Date:</strong> <?php echo e($date); ?></p>
            <p><strong>Status:</strong> <?php echo e($OrderStatus); ?></p>
            <p><strong>Delivery Address:</strong> <?php echo e($deliveryAddress); ?></p>
            <p><strong>Delivery Fee:</strong> <?php echo e($deliveryFee); ?></p>
        </div>

        <div class="contact-info">
            <p><strong>Best regards,</strong></p>
            <p><strong><?php echo e($companyName); ?></strong><br><?php echo e($tagLine); ?><br><?php echo e($address); ?><br><?php echo e($phone); ?><br><?php echo e($email); ?><br><?php echo e($website); ?><br></p>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\dex\Desktop\codecanyon-MlpTtcAY-pos-os-pos-invoice-inventory-accounting-staff-and-shop-management-software\source-code\backend\backend\resources\views\emails\StatusChange.blade.php ENDPATH**/ ?>