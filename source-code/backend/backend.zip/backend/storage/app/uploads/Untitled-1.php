<?php
// script: artisan tinker or small command
use Intervention\Image\Facades\Image;

$path = storage_path('app/uploads/os-inventory-logo.png');
Image::make($path)->resize(300, 300, function ($c) { $c->aspectRatio(); $c->upsize(); })
    ->save($path); // or save to a new filename